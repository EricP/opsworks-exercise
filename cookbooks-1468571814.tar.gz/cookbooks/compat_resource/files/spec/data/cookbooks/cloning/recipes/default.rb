log "stuff"

resource "doit"
